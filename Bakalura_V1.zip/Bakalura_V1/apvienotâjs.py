import glob
import ntpath
from pathlib import Path
import xlwings as xw
x=0
combined_wb=xw.Book()
excel_files=list()
for file in sorted(glob.glob("Sorted/Pages/*")):
    excel_files.append(file)
for excel_file in excel_files:
    wb = xw.Book(excel_file)
    for sheet in wb.sheets:
        size=len(excel_file)
        sheet.api.Copy(After=combined_wb.sheets[0].api)
        combined_wb.sheets[x-1].name = "{}".format(ntpath.basename(excel_file[:size-10]))
        x=x-1
    wb.close()
wb = xw.Book(excel_file)
combined_wb.sheets[0].delete()
combined_wb.save(f'Sorted/all_pages.xlsx')
if len(combined_wb.app.books) == 1:
     combined_wb.app.quit()
wb.close()