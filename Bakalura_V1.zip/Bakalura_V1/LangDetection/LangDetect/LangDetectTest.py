# Python program to demonstrate
# langdetect
  
from csv import reader
from langdetect import detect

with open("terms_all_lang.txt", "r+", encoding="utf-8-sig") as my_file:
    # pass the file object to reader()
    my_list = my_file.readlines()
    # do this for all the rows
    for i in my_list:
        print(i," ---> ", detect(str(i[1:])))
