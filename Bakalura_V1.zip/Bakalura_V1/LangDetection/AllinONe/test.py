from langdetect import detect, DetectorFactory
from csv import reader
DetectorFactory.seed = 0
k = 1
l=0
detected = 0
with open("KRyxo.csv", "r") as my_file:
    # pass the file object to reader()
    my_list = my_file.read().splitlines()
    # do this for all the rows
    for i in my_list:
        if k%2==0 :
            k=k+1
        else : 
            print(str(i[1:])," ---> ", detect(str(i[1:])))
            l = l+1
            if detect(str(i[1:])) == 'lv' :
                detected=detected+1
            k=k+1


print ("Kopa : ", l, "    Latviesu : ", detected)