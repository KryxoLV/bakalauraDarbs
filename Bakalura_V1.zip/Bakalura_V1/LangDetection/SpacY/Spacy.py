import spacy
from csv import reader
from spacy.language import Language
from spacy_langdetect import LanguageDetector
lv=0
la=0
ru=0
k=0
def get_lang_detector(nlp, name):
    return LanguageDetector()

nlp = spacy.load("en_core_web_sm")
Language.factory("language_detector", func=get_lang_detector)
nlp.add_pipe('language_detector', last=True)
with open('terms_all_lang.txt', 'r', encoding="utf-8") as read_obj:
    txt_reader = reader(read_obj, delimiter=',')
    for row in txt_reader:
        for i in range(0,len(row)):
            if(row[i]!=""):
                b = row[i]
                text = str(b)
                doc= nlp(text)
                print (doc , "----->", str(doc._.language))
                if ("lv" in str(doc._.language)):
                    lv=lv+1
                if ("ru" in str(doc._.language)):
                    ru=ru+1
                if ("la" in str(doc._.language)):
                    la=la+1
        k=k+1


print (k,lv,la,ru)