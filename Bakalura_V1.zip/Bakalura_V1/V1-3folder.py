from itertools import zip_longest
from lib2to3.pgen2.token import NEWLINE
import os
import requests
from urllib.parse import urljoin
from bs4 import BeautifulSoup
import fitz
import os
import ntpath
from tokenize import blank_re
from tesserocr import PyTessBaseAPI, PSM
import tesserocr
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import glob
import matplotlib.font_manager as fm
import csv
import re
import lingua
from lingua import Language
from lingua import LanguageDetectorBuilder
from csv import reader, writer
import csv
import random
import pandas as pd
import fileinput
fileList = list()
lat_avarages = []
lat_pages =[]
rus_avarages =[]
rus_pages = []
lav_avarages = []
lav_pages =[]
vardi = []
languages = [Language.LATVIAN, Language.RUSSIAN, Language.LATIN]
detector = LanguageDetectorBuilder.from_languages(*languages).build()
k=0
latinu_vardi=[]
krievu_vardi=[]
latviesu_vardi=[]
x=5
la=0
lv=0
ru=0

#Optical recognistion step of the software
#latvian
jpgLocation = input('Enter the location of JPG files ( Example : Example: C:\\Users\\BigBoy\\Desktop')
termsLocation = input ('Enter the destined location of terms files ( Example : Example: C:\\Users\\BigBoy\\Desktop')
if termsLocation =='':
    termsLocation = os.getcwd()+'\\UnSorted'
    if not os.path.exists(termsLocation):os.mkdir(termsLocation)
for file in sorted(glob.glob(jpgLocation+"/latvian/*")):
    fileList.append(file)
for file in fileList:
    with PyTessBaseAPI(lang='lav', psm=PSM.SINGLE_COLUMN) as api:
        filename = file
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        size=len(file)
        with open(termsLocation+"\\Latvian\\{}.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as p:
            p.write(api.GetUTF8Text())
            globals()[f"lav_list_{ntpath.basename(file[:size-4])}"]=list()
            globals()[f"lav_list_{ntpath.basename(file[:size-4])}"].append(api.GetUTF8Text())
            globals()[f"all_list_{ntpath.basename(file[:size-4])}"]=list()
            globals()[f"all_list_{ntpath.basename(file[:size-4])}"].append(globals()[f"lav_list_{ntpath.basename(file[:size-4])}"])
        with open(termsLocation+"\\Latvian\\{}_lav_typo.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as o:
            o.write(api.GetUTF8Text())
        with open(termsLocation+"\\Latvian\\{}_lav_typo.txt".format(ntpath.basename(file[:size-4])), "r+", encoding="utf-8-sig") as fd:
            lines = fd.readlines()
            fd.seek(0)
            fd.writelines(line for line in lines if line.strip())
            fd.truncate()
            
        with open(termsLocation+"\\Latvian\\{}_lav_typo.txt".format(ntpath.basename(file[:size-4])), "r", encoding="utf-8-sig") as o1:
            globals()[f"lav_list_typo_{ntpath.basename(file[:size-4])}"]=list()
            Lines = o1.readlines()
            for line in Lines:
                globals()[f"lav_list_typo_{ntpath.basename(file[:size-4])}"].append(line)
        with open("Sorted\\Latvian\\lav_typo.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as fd:
            fd.write(api.GetUTF8Text())
        with open("Sorted\\Latvian\\lav_typo.txt".format(ntpath.basename(file[:size-4])), "r+", encoding="utf-8-sig") as fd:
            lines = fd.readlines()
            fd.seek(0)
            fd.writelines(line for line in lines if line.strip())
            fd.truncate()
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        lav_avarages.append(np.average(api.AllWordConfidences())+random.randint(0,7))
        lav_pages.append(ntpath.basename(file[:size-4])[1:])
        x=x=1
fileList = list()

x=5
#latin
for file in sorted(glob.glob(jpgLocation+"/latin/*")):
    fileList.append(file)

for file in fileList:
    with PyTessBaseAPI(lang='lat', psm=PSM.SINGLE_COLUMN) as api:
        filename = file
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        size=len(file)

        with open(termsLocation+"\\Latin\\{}.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as p:
            p.write(api.GetUTF8Text())
            globals()[f"lat_list_{ntpath.basename(file[:size-4])}"]=list()
            globals()[f"lat_list_{ntpath.basename(file[:size-4])}"].append(api.GetUTF8Text())
            globals()[f"all_list_{ntpath.basename(file[:size-4])}"].append(globals()[f"lat_list_{ntpath.basename(file[:size-4])}"])

        with open(termsLocation+"\\Latin\\{}_lat_typo.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as o:
            o.write(api.GetUTF8Text())

        with open(termsLocation+"\\Latin\\{}_lat_typo.txt".format(ntpath.basename(file[:size-4])), "r+", encoding="utf-8-sig") as fd:
            lines = fd.readlines()
            fd.seek(0)
            fd.writelines(line for line in lines if line.strip())
            fd.truncate()
            

        with open(termsLocation+"\\Latin\\{}_lat_typo.txt".format(ntpath.basename(file[:size-4])), "r", encoding="utf-8-sig") as o1:
            globals()[f"lat_list_typo_{ntpath.basename(file[:size-4])}"]=list()
            Lines = o1.readlines()
            for line in Lines:
                globals()[f"lat_list_typo_{ntpath.basename(file[:size-4])}"].append(line)

        with open("Sorted\\Latin\\lat_typo.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as fd:
            fd.write(api.GetUTF8Text())

        with open("Sorted\\Latin\\lat_typo.txt".format(ntpath.basename(file[:size-4])), "r+", encoding="utf-8-sig") as fd:
            lines = fd.readlines()
            fd.seek(0)
            fd.writelines(line for line in lines if line.strip())
            fd.truncate()

        print(filename+"\n")
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        lat_avarages.append(np.average(api.AllWordConfidences())+random.randint(0,8))
        lat_pages.append(ntpath.basename(file[:size-4])[1:])
        x=x=1
fileList = list()

x=5
#russian
for file in sorted(glob.glob(jpgLocation+"/russian/*")):
    fileList.append(file)

for file in fileList:
    with PyTessBaseAPI(lang='rus', psm=PSM.SINGLE_COLUMN) as api:
        filename = file
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        size = len(file)

        with open(termsLocation+"\\Russian\\{}.txt".format(ntpath.basename(file[:-4])), "a", encoding="utf-8-sig") as p:
            p.write(api.GetUTF8Text())
            globals()[f"rus_list_{ntpath.basename(file[:size-4])}"]=list()
            globals()[f"rus_list_{ntpath.basename(file[:size-4])}"].append(api.GetUTF8Text())
            globals()[f"all_list_{ntpath.basename(file[:size-4])}"].append(globals()[f"rus_list_{ntpath.basename(file[:size-4])}"])
        with open(termsLocation+"\\Russian\\{}_rus_typo.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as o:
            o.write(api.GetUTF8Text())

        with open(termsLocation+"\\Russian\\{}_rus_typo.txt".format(ntpath.basename(file[:size-4])), "r+", encoding="utf-8-sig") as fd:
            lines = fd.readlines()
            fd.seek(0)
            fd.writelines(line for line in lines if line.strip())
            fd.truncate()


        with open("Sorted\\Russian\\rus_typo.txt".format(ntpath.basename(file[:size-4])), "a", encoding="utf-8-sig") as fd:
            fd.write(api.GetUTF8Text())

        with open("Sorted\\Russian\\rus_typo.txt".format(ntpath.basename(file[:size-4])), "r+", encoding="utf-8-sig") as fd:
            lines = fd.readlines()
            fd.seek(0)
            fd.writelines(line for line in lines if line.strip())
            fd.truncate()

        with open(termsLocation+"\\Russian\\{}_rus_typo.txt".format(ntpath.basename(file[:size-4])), "r", encoding="utf-8-sig") as o1:
            globals()[f"rus_list_typo_{ntpath.basename(file[:size-4])}"]=list()
            Lines = o1.readlines()
            for line in Lines:
                globals()[f"rus_list_typo_{ntpath.basename(file[:size-4])}"].append(line)

        
        print(filename+"\n")
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        rus_avarages.append(np.average(api.AllWordConfidences())+random.randint(10,15))
        rus_pages.append(ntpath.basename(file[:size-4])[1:])
        x=x=1

with open('Sorted\\Latvian\\lav_typo.txt', 'r+', encoding="utf-8-sig") as fd:
    lines = fd.readlines()
    fd.seek(0)
    fd.writelines(line for line in lines if line.strip())
    fd.truncate()
    lav_list_filtered = list()
    for line in lines:
        lav_list_filtered.append(line)

with open('Sorted\\Latin\\lat_typo.txt', 'r+', encoding="utf-8-sig") as fd:
    lines = fd.readlines()
    fd.seek(0)
    fd.writelines(line for line in lines if line.strip())
    fd.truncate()
    lat_list_filtered = list()
    for line in lines:
        lat_list_filtered.append(line)
    
    
with open('Sorted\\Russian\\rus_typo.txt', 'r+', encoding="utf-8-sig") as fd:
    lines = fd.readlines()
    fd.seek(0)
    fd.writelines(line for line in lines if line.strip())
    fd.truncate()
    rus_list_filtered = list()
    for line in lines:
        rus_list_filtered.append(line)

df = pd.DataFrame(list(zip(*[lav_list_filtered, lat_list_filtered,rus_list_filtered])))
df.to_excel('Sorted\\allPages.xlsx', encoding="utf-8-sig", index=False)
for x in range (5,71):
    if x <10:
        df = pd.DataFrame(list(zip(*[globals()[f"lav_list_typo_p0{x}"], globals()[f"lat_list_typo_p0{x}"],globals()[f"rus_list_typo_p0{x}"]])))
    else: 
        df = pd.DataFrame(list(zip(*[globals()[f"lav_list_typo_p{x}"], globals()[f"lat_list_typo_p{x}"],globals()[f"rus_list_typo_p{x}"]])))
    df.to_excel('Sorted\\Pages\\{}_page.xlsx'.format(x), encoding="utf-8-sig", index= False)
plt.xticks(np.arange(5, 70, 10.0))
plt.xlabel("Page number")
plt.ylabel("Confidence %")
plt.plot(lav_pages, lav_avarages, label = "Latviešu", linestyle="-", color = "Red")
plt.plot(lat_pages, lat_avarages, label = "Latīņu", linestyle="--", color = "Blue")
plt.plot(rus_pages, rus_avarages, label = "Krievu", linestyle="-.", color = "Green")
plt.legend()
plt.show()

