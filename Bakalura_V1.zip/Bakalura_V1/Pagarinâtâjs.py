from openpyxl import load_workbook
import re
pattern = '\D[.]'
pattern2 = '\D\D[.]'
workbook = load_workbook(filename="Sorted\\allPages.xlsx")
 
sheet = workbook.active
new_cell_obj = sheet.cell(row = sheet.min_row+1, column = sheet.min_column+1)
last_cell_obj = sheet.cell(row = sheet.min_row+1, column = sheet.min_column+1)
for x in range(1,sheet.max_column+1):
    for j in range (1,sheet.max_row+1):
        cell_obj = sheet.cell(row = j, column = x)
        print(cell_obj.value)
        new_cell_obj.value = ""
        for char in str(cell_obj.value):
            if char !='.':
                new_cell_obj.value = new_cell_obj.value + char
            else: 
                if re.match(pattern,cell_obj.value) or re.match(pattern2,cell_obj.value) :
                    last_cell_obj =sheet.cell(row = j-1, column = x)
                    new_cell_obj.value = re.sub(pattern, last_cell_obj.value.split()[0], cell_obj.value)
                    cell_obj.value = new_cell_obj.value
workbook.save(filename="Sorted\\test2.xlsx")