import matplotlib.pyplot as plt

import keras_ocr

# keras-ocr will automatically download pretrained
# weights for the detector and recognizer.
pipeline = keras_ocr.pipeline.Pipeline()

# Get a set of three example images
images = [
    keras_ocr.tools.read(url) for url in [
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRd0RXsFtb-E4EIZybffF5UfXwdzhwO1cAOWg&usqp=CAU',
        'https://upload.wikimedia.org/wikipedia/lv/2/22/Latvie%C5%A1u_konvers%C4%81cijas_v%C4%81rdn%C4%ABca.jpg'
    ]
]

# Each list of predictions in prediction_groups is a list of
# (word, box) tuples.
prediction_groups = pipeline.recognize(images)

# Plot the predictions
fig, axs = plt.subplots(nrows=len(images), figsize=(20, 20))
for ax, image, predictions in zip(axs, images, prediction_groups):
    keras_ocr.tools.drawAnnotations(image=image, predictions=predictions, ax=ax)