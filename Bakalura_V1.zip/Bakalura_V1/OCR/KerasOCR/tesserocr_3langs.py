import keras_ocr
import matplotlib.pyplot as plt
import glob
import csv
from PIL import Image

vardi =[]
fileList = list()
pipeline = keras_ocr.pipeline.Pipeline()

for file in sorted(glob.glob( "images/latin/*.png")):
    fileList.append(file)
with open("terms_all_lang.txt", "a", encoding="utf-8") as p:
    p.write("\n")
    p.write("Latīņu")
    p.write("\n")
for file in fileList:
  images = [
  keras_ocr.tools.read(file)
  ]
  prediction_groups = pipeline.recognize(images)
  predicted_image_1 = prediction_groups[0]
for text, box in predicted_image_1:
    with open("terms_all_lang.txt", "a", encoding="utf-8") as p:
      p.write(text)
      p.write("\n")
    print(text)

for file in sorted(glob.glob( "images/latvian/*.png")):
    fileList.append(file)
with open("terms_all_lang.txt", "a", encoding="utf-8") as p:
    p.write("\n")
    p.write("Latvieshu")
    p.write("\n")
for file in fileList:
  images = [
  keras_ocr.tools.read(file)
  ]
  prediction_groups = pipeline.recognize(images)
  predicted_image_1 = prediction_groups[0]
  for text, box in predicted_image_1:
    with open("terms_all_lang.txt", "a", encoding="utf-8") as p:
      p.write(text)
      p.write("\n")
    print(text)


for file in sorted(glob.glob( "images/russian/*.png")):
    fileList.append(file)
with open("terms_all_lang.txt", "a", encoding="utf-8") as p:
    p.write("\n")
    p.write("Krievu")
    p.write("\n")
for file in fileList:
  images = [
  keras_ocr.tools.read(file)
  ]
  prediction_groups = pipeline.recognize(images)
  predicted_image_1 = prediction_groups[0]
  for text, box in predicted_image_1:
    with open("terms_all_lang.txt", "a", encoding="utf-8") as p:
      p.write(text)
      p.write("\n")

    print(text)


with open("terms_all_lang.txt", 'r+', encoding="utf8") as fd:
  lines = fd.readlines()
  fd.seek(0)
  fd.writelines(line for line in lines if line.strip())
  fd.truncate()

file1 = open('terms_all_lang.txt', 'r', encoding="utf8")
Lines = file1.readlines()
# Strips the newline character
for line in Lines:
    vardi.append(line)

with open("terms_all_lang.csv", "w", encoding="utf16") as csvfile:
    writer = csv.writer(csvfile)
    for item in vardi:
        writer.writerow([item])
    