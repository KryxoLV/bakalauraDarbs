from tokenize import blank_re
from tesserocr import PyTessBaseAPI, PSM
import tesserocr
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import glob
import matplotlib.font_manager as fm
import csv
import re

print(tesserocr.tesseract_version())
fileList = list()
averages = []
vardi = []
pages = np.arange(5,71)



for file in sorted(glob.glob( "images/latin/*.png")):
    fileList.append(file)
for file in fileList:
    with PyTessBaseAPI(lang='lat', psm=PSM.SINGLE_COLUMN) as api:
        filename = file
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        with open("terms_all_lang.txt", "a", encoding="utf-16", newline='') as p:
            p.write(filename+"\n")
            p.write(api.GetUTF8Text())
        print(filename+"\n")
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        averages.append(np.average(api.AllWordConfidences()))
print(averages)
print(vardi)



# Edit the font, font size, and axes width
mpl.rcParams['font.family'] = 'Avenir'
plt.rcParams['font.size'] = 18
plt.rcParams['axes.linewidth'] = 2



plt.figure("results")
plt.plot(pages, averages, label="Latin terms")
#plt.show()
m, b = np.polyfit(pages, averages, 1)
plt.plot(pages, m*pages + b, linestyle='--', label="Latin trend")

latvian_avgs = []
with open("terms_all_lang.txt", "a", encoding="utf-16") as p:
            p.write("Latviski")
            p.write("\n")
fileList = list()
for file in sorted(glob.glob( "images/latvian/*.png")):
    fileList.append(file)

for file in fileList:
    

    #with PyTessBaseAPI(lang='lav+lat') as api:
    with PyTessBaseAPI(lang='lav', psm=PSM.SINGLE_COLUMN) as api:
        #api.SetImageFile('test_input.png')
        #filename = 'images/latin/p70.png'
        filename = file
        
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        with open("terms_all_lang.txt", "a", encoding="utf-16", newline='') as p:
            p.write(filename+"\n")
        with open("terms_all_lang.txt", "a", encoding="utf-16", newline='') as p:
            p.write(api.GetUTF8Text())
    
        print(filename+"\n")
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        latvian_avgs.append(np.average(api.AllWordConfidences()))



plt.figure("results")
plt.plot(pages,latvian_avgs,label="Latvian terms")
m2, b2 = np.polyfit(pages, latvian_avgs, 1)
plt.plot(pages, m2*pages + b2, linestyle='--', label="Latvian trend")


russian_avgs = []

fileList = list()
for file in sorted(glob.glob( "images/russian/*.png")):
    fileList.append(file)
with open("terms_all_lang.txt", "a", encoding="utf-16", newline='') as p:
            p.write("Krieviski")
            p.write("\n")
for file in fileList:
    

    #with PyTessBaseAPI(lang='lav+lat') as api:
    with PyTessBaseAPI(lang='rus', psm=PSM.SINGLE_COLUMN) as api:
        #api.SetImageFile('test_input.png')
        #filename = 'images/latin/p70.png'
        filename = file
        
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        with open("terms_all_lang.txt", "a", encoding="utf-16", newline='') as p:
            p.write(filename+"\n")
        with open("terms_all_lang.txt", "a", encoding="utf-16", newline='') as p:
            p.write(api.GetUTF8Text())
    
        print(filename+"\n")
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        russian_avgs.append(np.average(api.AllWordConfidences()))
with open("terms_all_lang.txt", 'r+', encoding="utf-16") as fd:
    lines = fd.readlines()
    fd.seek(0)
    fd.writelines(line for line in lines if line.strip())
    fd.truncate()

file1 = open('terms_all_lang.txt', 'r', encoding="utf-16")
Lines = file1.readlines()
# Strips the newline character
for line in Lines:
    vardi.append(line)

with open("terms_all_lang.csv", "w", encoding="utf16") as csvfile:
    writer = csv.writer(csvfile)
    for item in vardi:
        writer.writerow([item])


plt.figure("results")
plt.plot(pages,russian_avgs,label="Russian terms")
m2, b2 = np.polyfit(pages, russian_avgs, 1)
plt.plot(pages, m2*pages + b2, linestyle='--', label="Russian trend")


plt.grid(True)
plt.legend()
plt.xlabel("Page number")
plt.ylabel("Confidence %")
plt.show()