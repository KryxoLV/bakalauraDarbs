#!/usr/bin/env python3

import langid
langid.set_languages(['lv','la','ru'])
from langid.langid import LanguageIdentifier, model
identifier = LanguageIdentifier.from_modelstring(model, norm_probs=True)
identifier.set_languages(['lv','la','ru'])
k=0
l=0
la=0
kr=0
from csv import reader
results = [[0,0],[0,0],[0,0]]

with open('terms_all_lang.txt', 'r', encoding="utf-16") as read_obj:
    csv_reader = reader(read_obj, delimiter='	')
    for row in csv_reader:
        for i in range(0,len(row)):
            
            if(row[i]!=""):
                lang, score = identifier.classify(row[i])
                if("skat" not in row[i]):
                    results[i][1]+=1
                    if(lang == "lv"):
                        results[i][0]+=1
                        l=l+1
                    if(lang == "la"):
                        results[i][0]+=1
                        la=la+1
                    if(lang == "ru"):
                        results[i][0]+=1
                        kr=kr+1
                
                print(row[i], ' ->', lang,round(score,4))
                k = k+1
print("Kopā : ",k," Latviski: ",   l," Latīniski : ",    la,"Krieviski : ", kr)