import csv
import codecs
csvReader = csv.reader(codecs.open('terms_all_lang.csv', 'rU', 'utf-16'))
with open('terms_all_lang.csv', newline='') as in_file:
    with open('terms_all_lang2.csv', 'w', newline='', encoding="utf-16") as out_file:
        writer = csv.writer(out_file)
        for row in csvReader:
            if row:
                writer.writerow(row)