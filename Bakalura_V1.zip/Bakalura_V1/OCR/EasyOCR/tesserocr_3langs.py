from distutils import filelist
from shutil import register_unpack_format
import easyocr
import glob
import csv

vardi =[]
fileList = list()
reader = easyocr.Reader(['la'], gpu=True) # this needs to run only once to load the model into memory
for file in sorted(glob.glob( "images/latin/*.png")):
    fileList.append(file)
with open("allTerms.txt", "a", encoding="utf-8") as p:
    p.write("Latīniski ------------------------------------------")
    p.write("\n")

for file in fileList:
    result = reader.readtext(file, detail = 0)
    with open("allTerms.txt", "a", encoding="utf-8") as p:
        for ele in result:
            p.write(ele)
            p.write("\n")
    print(result)


reader = easyocr.Reader(['lv'], gpu=True) # this needs to run only once to load the model into memory
for file in sorted(glob.glob( "images/latvian/*.png")):
    fileList.append(file)
    with open("allTerms.txt", "a", encoding="utf-8") as p:
            p.write("Latviski ------------------------------------------")
            p.write("\n")


for file in fileList:
    result = reader.readtext(file, detail = 0)
    with open("allTerms.txt", "a", encoding="utf-8") as p:
        for ele in result:
            p.write(ele)
            p.write("\n")
    print(result)

reader = easyocr.Reader(['ru'], gpu=True) # this needs to run only once to load the model into memory
for file in sorted(glob.glob( "images/russian/*.png")):
    fileList.append(file)
    with open("allTerms.txt", "a", encoding="utf-8") as p:
        p.write("Krieviski ------------------------------------------")
        p.write("\n")


for file in fileList:
    result = reader.readtext(file, detail = 0)
    with open("allTerms.txt", "a", encoding="utf-8") as p:
        for ele in result:
            p.write(ele)
            p.write("\n")
    print(result)

with open("allTerms.txt", 'r+', encoding="utf8") as fd:
  lines = fd.readlines()
  fd.seek(0)
  fd.writelines(line for line in lines if line.strip())
  fd.truncate()

file1 = open('allTerms.txt', 'r', encoding="utf8")
Lines = file1.readlines()
# Strips the newline character
for line in Lines:
    vardi.append(line)

with open("terms_all_lang.csv", "w", encoding="utf16") as csvfile:
    writer = csv.writer(csvfile)
    for item in vardi:
        writer.writerow([item])