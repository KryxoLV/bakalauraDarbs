import csv
import re
import pandas as pd
ir = 0
kopigais = 0
with open("Sorted\\Latin\\lat_typo.txt", "r+", encoding="utf-8-sig") as fd:
    text = fd.readlines()
with open("Sorted\\Latvian\\lav_typo.txt", "r+", encoding="utf-8-sig") as fd:
    text = text + fd.readlines()
with open("Sorted\\Russian\\rus_typo.txt", "r+", encoding="utf-8-sig") as fd:
    text = text +  fd.readlines()
with open ("Sorted\\Ground_data\\Ground_data.txt", "r+", encoding="utf-8-sig") as f:
    text2 = f.readlines()

for elem in text:
    kopigais = kopigais+1
    if elem in text2:
        ir = ir + 1
print (len(text))
print(len(text2))
print (kopigais, round(kopigais*(ir / (len(text2)-len(text) - 2*ir))))
print((ir / (len(text2)-len(text) - (2*ir))*100))
