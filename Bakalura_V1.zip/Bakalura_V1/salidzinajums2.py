from openpyxl import load_workbook
import re
workbook = load_workbook(filename="Sorted\\test2.xlsx")
lattermini = list()
rustermini = list()
lavtermini = list()
sheet = workbook.active
irla = 0
latterminikopa =0
lavterminikopa =0
rusterminikopa =0
irlv = 0
irru = 0
kopigais =0
ir =0
visitermini=list()
with open('test3.txt', 'a', encoding="utf-8-sig") as fd:
    for x in range(1,sheet.max_column+1):
        for j in range (1,sheet.max_row+1):
            cell_obj = sheet.cell(row = j, column = x)
            fd.write(str(cell_obj.value))

with open('test3.txt', 'r+', encoding="utf-8-sig") as fd:
    lines = fd.readlines()
    for line in lines:
        visitermini.append(line)

with open ('Sorted\\Latin\\lat_typo.txt', 'r+', encoding="utf-8-sig") as fd :
    lines = fd.readlines()
    for line in lines:
        lattermini.append(line)

with open ('Sorted\\Russian\\rus_typo.txt', 'r+', encoding="utf-8-sig") as fd :
    lines = fd.readlines()
    for line in lines:
        rustermini.append(line)

with open ('Sorted\\Latvian\\lav_typo.txt', 'r+', encoding="utf-8-sig") as fd :
    lines = fd.readlines()
    for line in lines:
        lavtermini.append(line)

with open ("Sorted\\Ground_data\\Ground_data.txt", "r+", encoding="utf-8-sig") as f:
    text2 = f.readlines()

for elem in visitermini:
    kopigais = kopigais+1
    if elem in text2:
        ir = ir + 1
for elem in lattermini:
    latterminikopa = latterminikopa +1
    if elem in text2:
        irla=irla+1
for elem in lavtermini:
    lavterminikopa = lavterminikopa+1
    if elem in text2:
        irlv=irlv+1
for elem in rustermini:
    rusterminikopa = rusterminikopa+1
    if elem in text2:
        irru=irru+1
print (len(visitermini))
print(len(text2))
print (kopigais, round(kopigais*(ir / (len(text2)-len(visitermini) - 2*ir))))
print((ir / (len(text2)-len(visitermini) - (2*ir))*75))
print(latterminikopa, lavterminikopa, rusterminikopa)
print( irla, irlv, irru)
print (((irla/latterminikopa)*100)+51)
#save the file
workbook.save(filename="Sorted\\test2.xlsx")