import os
import requests
from urllib.parse import urljoin
from bs4 import BeautifulSoup
import fitz
import os
import ntpath
from tokenize import blank_re
from tesserocr import PyTessBaseAPI, PSM
import tesserocr
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import glob
import matplotlib.font_manager as fm
import csv
import re
import lingua
from lingua import Language
from lingua import LanguageDetectorBuilder
from csv import reader
import csv

fileList = list()
averages = []
vardi = []
languages = [Language.LATVIAN, Language.RUSSIAN, Language.LATIN]
detector = LanguageDetectorBuilder.from_languages(*languages).build()
k=0
latinu_vardi=[]
krievu_vardi=[]
latviesu_vardi=[]
la=0
lv=0
ru=0

#PDF download step of the software
url = input("Enter the URL")
location = input("Enter the folder ( Example : C:\\users\\test\\testFolder )")
folder_location = location
if not os.path.exists(folder_location):os.mkdir(folder_location)
response = requests.get(url)
soup= BeautifulSoup(response.text, "html.parser")     
for link in soup.select("a[href$='.pdf']"):
    #Name the pdf files using the last portion of each link which are unique in this case
    filename = os.path.join(folder_location,link['href'].split('/')[-1])
    with open(filename, 'wb') as f:
        f.write(requests.get(urljoin(url,link['href'])).content)
print('File with name ', filename, ' downloaded from url ', url, ' and saved in directory ', location)


#PDF converting to JPG step of the software
pdf_file = input("Enter the path to pdf_file ( Example: C:\\Users\\BigBoy\\Desktop\\17363360.pdf )")
doc = fitz.open(pdf_file)
zoom = input("Enter the zoom amount - this will determine the quelity from 1 to 5 (drasticly increases the time needed to convert the PDF to JPG)")
mat = fitz.Matrix(zoom, zoom)
noOfPages = doc.pageCount
newpathA= input("Enter the path to where generate the converted PDF pages")
size = len(pdf_file)
newPathB = newpathA+'\\{}\\'.format(ntpath.basename(pdf_file[:size-4]))
newpath = newPathB
print (newpath)
if not os.path.exists(newpath):
    os.makedirs(newPathB)
image_folder = newpath

for pageNo in range(noOfPages):
    page = doc.loadPage(pageNo) 
    pix = page.getPixmap(matrix = mat)
    output = image_folder + str(pageNo) + '.jpg'
    pix.writePNG(output)
    print('PDF converting is ongoing on ' + output)
print('PDF converting completed and saved in directory ', newpath)

#Optical recognistion step of the software
jpgLocation = input('Enter the location of JPG files ( Example : Example: C:\\Users\\BigBoy\\Desktop')
termsLocation = input ('Enter the destined location of terms files ( Example : Example: C:\\Users\\BigBoy\\Desktop')
for file in sorted(glob.glob(jpgLocation+"/*")):
    fileList.append(file)
for file in fileList:
    with PyTessBaseAPI(lang='lav', psm=PSM.SINGLE_COLUMN) as api:
        filename = file
        api.SetImageFile(filename)
        print(api.GetUTF8Text())
        with open(termsLocation+"/terms_all_lang.txt", "a", encoding="utf-8") as p:
            p.write(api.GetUTF8Text())
        print(filename+"\n")
        print("Confidence:")
        print(api.AllWordConfidences())
        print("AVG: " , np.average(api.AllWordConfidences()))
        averages.append(np.average(api.AllWordConfidences()))
print(averages)
with open(termsLocation+"/terms_all_lang.txt", 'r+', encoding="utf8") as fd:
    lines = fd.readlines()
    fd.seek(0)
    fd.writelines(line for line in lines if line.strip())
    fd.truncate()

file1 = open(termsLocation+"/terms_all_lang.txt", 'r', encoding="utf8")
Lines = file1.readlines()
for line in Lines:
    vardi.append(line)

with open(termsLocation+"/terms_all_lang.csv", "w", encoding="utf16", newline='') as csvfile:
    writer = csv.writer(csvfile)
    for item in vardi:
        writer.writerow([item])

# Clasification based on lanugage of the termins part of software
f = open(termsLocation +"/terms_all_lang.txt", "r", encoding="utf8")
lines = f.readlines()
for line in lines:
    print(line , "--- > ", detector.detect_language_of(line))
    if detector.detect_language_of(line)==Language.LATIN:
        latinu_vardi.append(line)
        la=la+1
    if detector.detect_language_of(line)==Language.LATVIAN:
        latviesu_vardi.append(line)
        lv=lv+1
    if detector.detect_language_of(line)==Language.RUSSIAN:
        krievu_vardi.append(line)
        ru=ru+1
    k=k+1
f.close()
if not os.path.exists(termsLocation+"\\Sorted"):os.mkdir(termsLocation+"\\Sorted")
with open(termsLocation+"\\Sorted\\RussianTerms.csv", "w", encoding="utf16", newline = '') as csvfile:
    writer = csv.writer(csvfile)
    for item in krievu_vardi:
        writer.writerow([item])
with open(termsLocation+"\\Sorted\\LatvianTerms.csv", "w", encoding="utf16", newline = '') as csvfile:
    writer = csv.writer(csvfile)
    for item in latviesu_vardi:
        writer.writerow([item])
with open(termsLocation+"\\Sorted\\LatinTerms.csv", "w", newline = '', encoding="utf16") as csvfile:
    writer = csv.writer(csvfile)
    for item in latinu_vardi:
        writer.writerow([item])

print("kopa, latinu, latviesu, krievu, nenolasami")
print (k,la,lv,ru,k-(la+lv+ru))