import fitz
import os
import ntpath
pdf_file = input ('Enter the location OF PDF file ( Example : Example: C:\\Users\\BigBoy\\Desktop')
doc = fitz.open(pdf_file)
zoom = 2
mat = fitz.Matrix(zoom, zoom)
noOfPages = doc.pageCount
newpath =(pdf_file+'\\{}\\'.format(ntpath.basename(pdf_file)))
if not os.path.exists(newpath):
    os.makedirs(newpath)
image_folder = newpath

for pageNo in range(noOfPages):
    page = doc.loadPage(pageNo) 
    pix = page.getPixmap(matrix = mat)
    
    output = image_folder + str(pageNo) + '.jpg'
    pix.writePNG(output)
    print('Tiek veikta PDFs konvertēšana par PNG ... ' + output)