from lingua import Language, LanguageDetectorBuilder
from csv import reader
import csv
languages = [Language.LATVIAN, Language.RUSSIAN, Language.LATIN]
detector = LanguageDetectorBuilder.from_languages(*languages).build()
k=0
latinu_vardi=[]
krievu_vardi=[]
latviesu_vardi=[]
la=0
lv=0
ru=0
f = open('terms_all_lang.txt', "r", encoding="utf-8-sig")
lines = f.readlines()
for line in lines:
    print(line , "--- > ", detector.detect_language_of(line))
    if detector.detect_language_of(line)==Language.LATIN:
        latinu_vardi.append(line)
        la=la+1
    if detector.detect_language_of(line)==Language.LATVIAN:
        latviesu_vardi.append(line)
        lv=lv+1
    if detector.detect_language_of(line)==Language.RUSSIAN:
        krievu_vardi.append(line)
        ru=ru+1
    k=k+1
f.close()


with open("Sorted/RussianTerms.csv", "w", encoding="utf-8-sig", newline = '') as csvfile:
    writer = csv.writer(csvfile)
    for item in krievu_vardi:
        writer.writerow([item])
with open("Sorted/LatvianTerms.csv", "w", encoding="utf-8-sig", newline = '') as csvfile:
    writer = csv.writer(csvfile)
    for item in latviesu_vardi:
        writer.writerow([item])
with open("Sorted/LatinTerms.csv", "w", newline = '', encoding="utf-8-sig") as csvfile:
    writer = csv.writer(csvfile)
    for item in latinu_vardi:
        writer.writerow([item])

print("kopa, latinu, latviesu, krievu, nenolasami")
print (k,la,lv,ru,k-(la+lv+ru))